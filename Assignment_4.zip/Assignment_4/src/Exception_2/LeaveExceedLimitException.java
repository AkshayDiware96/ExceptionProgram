package Exception_2;

class LeaveExceedLimitException extends Exception {

	public LeaveExceedLimitException(String message) {
		super(message);

	}

}
