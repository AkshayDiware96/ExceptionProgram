package Exception_5;

class Passenger_detailException extends Exception {

	public Passenger_detailException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
