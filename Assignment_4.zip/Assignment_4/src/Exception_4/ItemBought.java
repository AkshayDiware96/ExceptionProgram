package Exception_4;

public class ItemBought {

	long itemid;
	int itemqty;

}
