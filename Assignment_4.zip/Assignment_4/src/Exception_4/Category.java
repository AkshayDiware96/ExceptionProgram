package Exception_4;

public class Category {

	long catid;
	String categoryname;

}
