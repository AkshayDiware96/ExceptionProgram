package Exception_4;

public class InputException extends RuntimeException {

	public InputException(String s) {

		super(s);
	}

}
