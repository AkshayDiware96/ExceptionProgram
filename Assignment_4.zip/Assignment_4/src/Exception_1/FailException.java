package Exception_1;

public class FailException extends RuntimeException {

	public FailException(String s) {
		super(s);

	}
}