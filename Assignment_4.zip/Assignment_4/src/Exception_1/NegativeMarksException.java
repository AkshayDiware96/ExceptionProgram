package Exception_1;

public class NegativeMarksException extends RuntimeException {

	public NegativeMarksException(String s) {
		super(s);

	}
}