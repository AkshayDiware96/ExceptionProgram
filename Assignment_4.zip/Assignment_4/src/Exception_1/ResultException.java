package Exception_1;

public class ResultException extends RuntimeException {

	public ResultException(String s) {
		super(s);

	}

}
